﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using midtermexam.Data.Entities;
using midtermexam.Models.DTOs;

namespace midtermexam.Service.Interfaces
{
    public interface IPlayerService
    {
        IEnumerable<PlayerDTO> GetPlayers();
        Task<PlayerDTO> GetPlayerById(int id);
        PlayerDTO AddPlayer(PlayerDTO student);
        PlayerDTO UpdatePlayer(PlayerDTO student);
        Task<bool> DeletePlayer(int id);
    }
}