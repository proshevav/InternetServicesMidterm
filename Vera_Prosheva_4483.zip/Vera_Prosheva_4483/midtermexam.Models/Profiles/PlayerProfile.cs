﻿using AutoMapper;
using midtermexam.Data.Entities;
using midtermexam.Models.DTOs;

namespace midtermexam.Models.Profiles
{
    public class PlayerProfile : Profile
    {
        public PlayerProfile()
        {
            CreateMap<Player, PlayerDTO>()
                .ReverseMap();
        }
    }
}
