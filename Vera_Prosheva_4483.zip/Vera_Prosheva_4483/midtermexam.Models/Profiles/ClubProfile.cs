﻿using AutoMapper;
using midtermexam.Data.Entities;
using midtermexam.Models.DTOs;

namespace midtermexam.Models.Profiles
{
    public class ClubProfile : Profile
    {
        public ClubProfile()
        {
            CreateMap<Club, ClubDTO>()
                .ReverseMap();
        }
    }
}